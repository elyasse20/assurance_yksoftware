// import { BrowserRouter, Routes, Route } from "react-router-dom";
// import { AuthProvider } from "./context/AuthContext";
// import Login from "./pages/Login";
// import Dashboard from "./pages/Dashboard";
// import Admin from "./pages/Admin";
// import NotAuthorized from "./pages/NotAuthorized";
// import ProtectedRoute from "./components/ProtectedRoute";
// import AdminRoute from "./components/AdminRoute";
// import AddSimpleItem from "./components/AddSimpleItem";
// import AddCompagne from "./components/AddCompagne";
// import ListClient from "./components/ListClient";
// import EditSimpleItem from "./components/EditSimpleItem";

// export default function App() {
//   return (<>
          

//     <AuthProvider>
//       <BrowserRouter>
//         <Routes>
//           <Route path="/" element={<Login />} />
//           <Route
//             path="/dashboard"
//             element={
//               <ProtectedRoute>
//                 <Dashboard />
//               </ProtectedRoute>
//             }
//           />
//             <Route
//             path="/clients"
//             element={
//               <ProtectedRoute>
//                 <ListClient />
//               </ProtectedRoute>
//             }
//           />
//               <Route
//             path="/categories"
//             element={
//               <ProtectedRoute>
//                 <AddSimpleItem title={"Categorie"} endpoint={"categories"} />
//               </ProtectedRoute>
//             }
//           />
//              <Route
//             path="/compagnes"
//             element={
//               <ProtectedRoute>
//                 <AddCompagne />
//               </ProtectedRoute>
//             }
//           />
//               <Route
//             path="/parametres"
//             element={
//               <ProtectedRoute>
//                 <AddSimpleItem title={"Parametre"} endpoint={"parametres"} />
//               </ProtectedRoute>
//             }
//           />
//              {/* <Route
//             path="/parametre/:id"
//             element={
//               <ProtectedRoute>
//                 <EditSimpleItem title={"Parametre"} endpoint={"parametres"} />
//               </ProtectedRoute>
//             }
//           /> */}
//                 <Route
//             path="/natures"
//             element={
//               <ProtectedRoute>
//                 <AddSimpleItem title={"Nature"} endpoint={"natures"} />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/admin"
//             element={
//               <AdminRoute>
//                 <Admin />
//               </AdminRoute>
//             }
//           />
//           <Route path="/unauthorized" element={<NotAuthorized />} />
//         </Routes>
//       </BrowserRouter>
//     </AuthProvider></>
//   );
// }


import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Login from "./pages/Login";
import NotAuthorized from "./pages/NotAuthorized";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminRoute from "./components/AdminRoute";
import AddSimpleItem from "./components/AddSimpleItem";
// import AddCompagne from "./components/AddCompagne";
import ListClient from "./components/ListClient";
import ListOperation from "./components/ListOperation";
import ListCompagne from "./components/ListCompagne";
import ListUser from "./components/ListUser";
export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />

  

          <Route
            path="/clients"
            element={
              <ProtectedRoute>
                <ListClient />
              </ProtectedRoute>
            }
          />

          <Route
            path="/categories"
            element={
              <ProtectedRoute>
                <AddSimpleItem title="Categorie" endpoint="categories" />
              </ProtectedRoute>
            }
          />
  <Route
            path="/operations"
            element={
              <ProtectedRoute>
                <ListOperation />
              </ProtectedRoute>
            }
          />
            <Route
            path="/compagnes"
            element={
              <ProtectedRoute>
                <ListCompagne />
              </ProtectedRoute>
            }
          />
             <Route
            path="/users"
            element={
              <AdminRoute>
                <ListUser />
              </AdminRoute>
            }
          />
          <Route
            path="/parametres"
            element={
              <ProtectedRoute>
                <AddSimpleItem title="Parametre" endpoint="parametres" />
              </ProtectedRoute>
            }
          />

      

          <Route
            path="/natures"
            element={
              <ProtectedRoute>
                <AddSimpleItem title="Nature" endpoint="natures" />
              </ProtectedRoute>
            }
          />

       

          <Route path="/unauthorized" element={<NotAuthorized />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
