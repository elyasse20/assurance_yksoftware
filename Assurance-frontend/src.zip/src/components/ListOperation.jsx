import { useState, useEffect, useMemo } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { Navbar } from "./NavBar";
import OperationTable from "./OperationTable";

export default function ListOperation() {
  const { user, logout } = useAuth();
  const [editId, setEditId] = useState(null);
  const [step, setStep] = useState(1);
  const [reload, setReload] = useState(false);
  const [allCompagnes, setAllCompagnes] = useState([]);
  const [allCategories, setAllCategories] = useState([]);
  const [allNatures, setAllNatures] = useState([]);
  const [filteredClients, setFilteredClients] = useState([]);
  const [displayMonth, setDisplayMonth] = useState("");
  const [compagneParams, setCompagneParams] = useState([]);

  const [formData, setFormData] = useState({
    natureOperation: "",
    client: "",
    dateEff: "",
    moisDem: "",
    category: "",
    numpolice: "",
    parameters: [],
  });

  // load lists
  useEffect(() => {
    const headers = { Authorization: `Bearer ${user?.token}` };
    axios.get("http://localhost:5000/api/compagnes", { headers }).then((r) => setAllCompagnes(r.data || []));
    axios.get("http://localhost:5000/api/categories", { headers }).then((r) => setAllCategories(r.data || []));
    axios.get("http://localhost:5000/api/natures", { headers }).then((r) => setAllNatures(r.data || []));
  }, [user]);

  // handle field change
  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "category") {
      setFormData((prev) => ({ ...prev, category: value, client: "", numpolice: "" }));
      const filtered = allCompagnes.filter((c) => c.category === value);
      const clientsByCategory = filtered.map((c) => ({ clientName: c.clientName, indec: c.indec }));
      setFilteredClients(clientsByCategory);
      setCompagneParams([]);
    } else if (name === "client") {
      const selectedClient = value;
      const matchedCompagne = allCompagnes.find(
        (c) => c.clientName === selectedClient && c.category === formData.category
      );
      const prefix = matchedCompagne?.indec ? `${matchedCompagne.indec}-` : "";
      setFormData((prev) => ({
        ...prev,
        client: selectedClient,
        numpolice: prefix,
      }));
      setCompagneParams(matchedCompagne?.parameters || []);
    } else if (name === "moisDem") {
      const [year, month] = value.split("-");
      const formatted = new Date(year, month - 1).toLocaleDateString("fr-FR", {
        month: "short",
        year: "2-digit",
      });
      setDisplayMonth(formatted);
      setFormData((prev) => ({ ...prev, moisDem: value }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleValueChange = (paramName, field, value) => {
    setFormData((prev) => {
      const exists = prev.parameters.some((p) => p.name === paramName);
      const updated = exists
        ? prev.parameters.map((p) =>
            p.name === paramName ? { ...p, [field]: Number(value) } : p
          )
        : [
            ...prev.parameters,
            { name: paramName, primes: 0, taxe: 0, taxepara: 0, accessoire: 0, cnpc: 0, [field]: Number(value) },
          ];
      return { ...prev, parameters: updated };
    });
  };

  const computeParamTotal = (param) =>
    (param.primes || 0) +
    (param.taxe || 0) +
    (param.taxepara || 0) +
    (param.accessoire || 0) +
    (param.cnpc || 0);

  const totalGeneral = useMemo(
    () => formData.parameters.reduce((sum, p) => sum + computeParamTotal(p), 0),
    [formData.parameters]
  );

  const handleEdit = (operation) => {
    setEditId(operation._id);
    setFormData({
      natureOperation: operation.natureOperation || "",
      client: operation.client || "",
      dateEff: operation.dateEff ? operation.dateEff.split("T")[0] : "",
      moisDem: operation.moisDem || "",
      category: operation.category || "",
      numpolice: operation.numpolice || "",
      parameters: operation.parameters || [],
    });
    const matchedCompagne = allCompagnes.find(
      (c) => c.clientName === operation.client && c.category === operation.category
    );
    setCompagneParams(matchedCompagne?.parameters || []);
    setStep(1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const headers = { Authorization: `Bearer ${user?.token}` };
    const payload = { ...formData };

    try {
      if (editId) {
        await axios.put(`http://localhost:5000/api/productions/${editId}`, payload, { headers });
        alert("✅ Opération modifiée avec succès");
      } else {
        await axios.post("http://localhost:5000/api/productions", payload, { headers });
        alert("✅ Opération enregistrée");
      }
      resetForm();
      setReload((prev) => !prev); // 🔁 trigger refresh
    } catch (err) {
      console.error(err);
      alert("❌ Erreur lors de l’envoi");
    }
  };

  const resetForm = () => {
    setFormData({
      natureOperation: "",
      client: "",
      dateEff: "",
      moisDem: "",
      category: "",
      numpolice: "",
      parameters: [],
    });
    setFilteredClients([]);
    setCompagneParams([]);
    setDisplayMonth("");
    setStep(1);
    setEditId(null);
  };

  return (
    <>
      <Navbar lg={logout} />
      <div className="container mt-4">
          
            {/* FORM */}
            <div className="border rounded p-4 bg-light shadow-sm">
              <h4 className="text-center mb-3">{editId ? "Modifier une opération" : "Ajouter une opération"}</h4>

              <form onSubmit={handleSubmit}>
                {/* --- STEP 1 --- */}
                {step === 1 && (
                  <>
                    <div className="mb-2">
                      <label className="form-label">Nature d’opération</label>
                      <select
                        name="natureOperation"
                        value={formData.natureOperation}
                        onChange={handleChange}
                        className="form-select"
                        required
                      >
                        <option value="">-- Sélectionner une nature --</option>
                        {allNatures.map((n) => (
                          <option key={n._id} value={n.name}>{n.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="row">
                      <div className="col-md-6 mb-2">
                        <label className="form-label">Date d’effet</label>
                        <input
                          type="date"
                          name="dateEff"
                          value={formData.dateEff}
                          onChange={handleChange}
                          className="form-control"
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-2">
                        <label className="form-label">Mois d’émission</label>
                        <div className="input-group">
                          <input
                            type="month"
                            name="moisDem"
                            value={formData.moisDem}
                            onChange={handleChange}
                            className="form-control"
                            required
                          />
                          <span className="input-group-text bg-light text-dark">{displayMonth || "—"}</span>
                        </div>
                      </div>
                    </div>
                    <div className="mb-2">
                      <label className="form-label">Catégorie</label>
                      <select
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                        className="form-select"
                        required
                      >
                        <option value="">-- Sélectionner une catégorie --</option>
                        {allCategories.map((cat) => (
                          <option key={cat._id} value={cat.name}>{cat.name}</option>
                        ))}
                      </select>
                    </div>

                    {filteredClients.length > 0 && (
                      <div className="mb-2">
                        <label className="form-label">Client</label>
                        <select
                          name="client"
                          value={formData.client}
                          onChange={handleChange}
                          className="form-select"
                          required
                        >
                          <option value="">-- Sélectionner un client --</option>
                          {filteredClients.map((c, i) => (
                            <option key={i} value={c.clientName}>{c.clientName}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div className="mb-2">
                      <label className="form-label">Numéro Police</label>
                      <input
                        type="text"
                        name="numpolice"
                        value={formData.numpolice}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>


                    <div className="text-center mt-3">
                      <button type="button" className="btn btn-outline-dark px-4" onClick={() => setStep(2)}>
                        Suivant →
                      </button>
                    </div>
                  </>
                )}

                {/* --- STEP 2 --- */}
                {step === 2 && (
                  <>
                    {compagneParams.length > 0 ? (
                      compagneParams.map((p, index) => {
                        const checked = formData.parameters.some((x) => x.name === p.name);
                        const current = formData.parameters.find((x) => x.name === p.name) || {};
                        const total = computeParamTotal(current);
                        return (
                          <div key={index} className="border rounded p-2 mb-3 bg-light">
                            <div className="form-check mb-2">
                              <input
                                type="checkbox"
                                className="form-check-input"
                                checked={checked}
                                onChange={(e) =>
                                  e.target.checked
                                    ? setFormData((prev) => ({
                                        ...prev,
                                        parameters: [
                                          ...prev.parameters,
                                          { name: p.name, primes: 0, taxe: 0, taxepara: 0, accessoire: 0, cnpc: 0 },
                                        ],
                                      }))
                                    : setFormData((prev) => ({
                                        ...prev,
                                        parameters: prev.parameters.filter((x) => x.name !== p.name),
                                      }))
                                }
                              />
                              <label className="form-check-label ms-2 fw-semibold">
                                {p.name} ({p.percent}%)
                              </label>
                            </div>

                            {checked && (
                              <>
                                <div className="d-flex justify-content-between flex-wrap gap-2 text-center mt-2">
                                  {[
                                    { key: "primes", label: "Primes" },
                                    { key: "taxe", label: "Taxe" },
                                    { key: "taxepara", label: "Taxe Para" },
                                    { key: "accessoire", label: "Accessoire" },
                                    { key: "cnpc", label: "CNPC" },
                                  ].map((f) => (
                                    <div key={f.key} className="d-flex flex-column align-items-center" style={{ minWidth: "85px" }}>
                                      <label className="form-label mb-1 fw-normal" style={{ fontSize: "12px" }}>
                                        {f.label}
                                      </label>
                                      <input
                                        type="number"
                                        className="form-control form-control-sm text-center"
                                        style={{ width: "75px" }}
                                        value={current[f.key] || ""}
                                        onChange={(e) => handleValueChange(p.name, f.key, e.target.value)}
                                      />
                                    </div>
                                  ))}
                                </div>
                                <div className="text-end mt-2">
                                  <span className="badge bg-dark">Total paramètre: {total.toFixed(2)} DH</span>
                                </div>
                              </>
                            )}
                          </div>
                        );
                      })
                    ) : (
                      <p className="text-muted text-center">Aucun paramètre à afficher</p>
                    )}

                    {formData.parameters.length > 0 && (
                      <div className="text-end mt-4">
                        <h6 className="fw-bold">
                          Total général: <span className="text-success">{totalGeneral.toFixed(2)} DH</span>
                        </h6>
                      </div>
                    )}

                    <div className="d-flex justify-content-between mt-3">
                      <button type="button" className="btn btn-outline-secondary" onClick={() => setStep(1)}>
                        ← Précédent
                      </button>

                      {editId ? (
                        <>
                          <button type="button" className="btn btn-secondary" onClick={resetForm}>Annuler</button>
                          <button type="submit" className="btn btn-dark px-4">Mettre à jour</button>
                        </>
                      ) : (
                        <button type="submit" className="btn btn-dark px-4">Enregistrer</button>
                      )}
                    </div>
                  </>
                )}
              </form>
            </div>
          

          
            <OperationTable onEdit={handleEdit} reload={reload} />
          
      </div>
    </>
  );
}
