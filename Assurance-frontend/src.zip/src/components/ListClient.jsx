import { useState, useRef, useEffect } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { Navbar } from "./NavBar";
import ClientTable from "./Table";

export default function ListClient() {
  const { user, logout } = useAuth();
  const fileInputRef = useRef(null);
  const [editId, setEditId] = useState(null);
  const [formData, setFormData] = useState({
    type: "particulier",
    cin: "",
    nom: "",
    prenom: "",
    tel: "",
    adresse: "",
    doc: null,
    ice: "",
    if: "",
    rc: "",
    budget: 0,
  });
  useEffect(
    ()=>{
console.log(user)

    },[]
  )
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFile = (e) => {
    setFormData((prev) => ({ ...prev, doc: e.target.files[0] }));
  };
  
  // receive data from ClientTable edit
  const handleEdit = (client) => {
    setEditId(client._id);
    setFormData({
      type: client.type || "particulier",
      cin: client.cin || "",
      nom: client.nom || "",
      prenom: client.prenom || "",
      tel: client.tel || "",
      adresse: client.adresse || "",
      doc: null,
      ice: client.ice || "",
      if: client.if || "",
      rc: client.rc || "",
      budget: client.budget || 0,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    Object.entries(formData).forEach(([key, value]) =>
      data.append(key, value instanceof Date ? value.toISOString() : value)
    );

    try {
      if (editId) {
        await axios.put(`http://localhost:5000/api/clients/${editId}`, data, {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${user?.token}`,
          },
        });
        alert("✅ Client modifié avec succès");
        setEditId(null);
      } else {
        await axios.post("http://localhost:5000/api/clients", data, {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${user?.token}`,
          },
        });
        alert("✅ Client ajouté avec succès");
      }

      setFormData({
        type: "particulier",
        cin: "",
        nom: "",
        prenom: "",
        tel: "",
        adresse: "",
        doc: null,
        ice: "",
        if: "",
        rc: "",
        budget: 0,
      });
      if (fileInputRef.current) fileInputRef.current.value = "";
    } catch (err) {
      console.error(err);
      alert("❌ Erreur lors de l’envoi du client");
    }
  };

  return (
    <>
      <Navbar lg={logout} />
      <div className="container mt-4">
        <div className="row">
          {/* Form section */}
          <div className="col-lg-5 d-flex align-items-center">
            <div className="w-100 border rounded p-4 bg-light shadow-sm">
              <h3 className="text-center mb-3">
                {editId ? "Modifier le client" : "Ajouter un client"}
              </h3>

              <form onSubmit={handleSubmit}>
                {/* Type */}
                <div className="mb-1">
                  <label className="form-label">Type</label>
                  <select
                    name="type"
                    value={formData.type}
                    onChange={handleChange}
                    className="form-select"
                  >
                    <option value="particulier">Particulier</option>
                    <option value="societe">Société</option>
                  </select>
                </div>

                {/* Nom / Prénom */}
                <div className="row">
                  <div
                    className={`${formData.type === "particulier" && "col-md-6"} mb-1`}
                  >
                    <label className="form-label">Nom</label>
                    <input
                      type="text"
                      name="nom"
                      value={formData.nom}
                      onChange={handleChange}
                      className="form-control"
                      required
                    />
                  </div>
                  <div className="col-md-6 mb-1">
                    {formData.type === "particulier" && (
                      <>
                        <label className="form-label">Prénom</label>
                        <input
                          type="text"
                          name="prenom"
                          value={formData.prenom}
                          onChange={handleChange}
                          className="form-control"
                          required
                        />
                      </>
                    )}
                  </div>
                </div>

                {/* CIN */}
                {formData.type === "particulier" && (
                  <div className="mb-1">
                    <label className="form-label">CIN</label>
                    <input
                      type="text"
                      name="cin"
                      value={formData.cin}
                      onChange={handleChange}
                      className="form-control"
                      required
                    />
                  </div>
                )}

                {/* Téléphone */}
                <div className="mb-1">
                  <label className="form-label">Téléphone</label>
                  <input
                    type="text"
                    name="tel"
                    value={formData.tel}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>

                {/* Adresse */}
                <div className="mb-1">
                  <label className="form-label">Adresse</label>
                  <input
                    type="text"
                    name="adresse"
                    value={formData.adresse}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>

                {/* Société fields */}
                {formData.type === "societe" && (
                  <div className="row">
                    <div className="col-md-4 mb-1">
                      <label className="form-label">ICE</label>
                      <input
                        type="text"
                        name="ice"
                        value={formData.ice}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    <div className="col-md-4 mb-1">
                      <label className="form-label">IF</label>
                      <input
                        type="text"
                        name="if"
                        value={formData.if}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                    <div className="col-md-4 mb-1">
                      <label className="form-label">RC</label>
                      <input
                        type="text"
                        name="rc"
                        value={formData.rc}
                        onChange={handleChange}
                        className="form-control"
                        required
                      />
                    </div>
                  </div>
                )}

                {/* Budget */}
                <div className="mb-1">
                  <label className="form-label">Budget</label>
                  <input
                    type="number"
                    name="budget"
                    value={formData.budget}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>

                {/* Document */}
                <div className="mb-2">
                  <label className="form-label">Document (image/pdf)</label>
                  <input
                    type="file"
                    name="doc"
                    ref={fileInputRef}
                    onChange={handleFile}
                    className="form-control"
                    accept="image/*,application/pdf"
                  />
                </div>

                {/* Submit */}
                {editId?( 
                <div className="d-flex justify-content-between">
            <div className="btn btn-secondary"  onClick={() => {
        setEditId(null);
        setFormData({
          type: "particulier",
          cin: "",
          nom: "",
          prenom: "",
          tel: "",
          adresse: "",
          doc: null,
          ice: "",
          if: "",
          rc: "",
          budget: 0,
        });
        if (fileInputRef.current) fileInputRef.current.value = "";
      }}>
              Annuler
            </div>
         <button type="submit" className="btn btn-dark px-4">
                    Mettre à jour 
                  </button>
          </div>)
               :( <div className="text-center">
                     <button type="submit" className="btn btn-dark px-4">
              Enregistrer
            </button>
                </div>
                )
                
                
          }
              </form>
            </div>
          </div>

          {/* Table section */}
          <div className="col-lg-7">
            <ClientTable onEdit={handleEdit} />
          </div>
        </div>
      </div>
    </>
  );
}
