import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { FaEdit, FaTrash } from "react-icons/fa";

export default function OperationTable({ onEdit, reload }) {
  const [operations, setOperations] = useState([]);
  const [params, setparams] = useState([]);

  const [currentPage, setCurrentPage] = useState(1);
  const [perPage] = useState(2);
  const { user } = useAuth();

  useEffect(() => {
        axios
      .get("http://localhost:5000/api/parametres", {
        headers: { Authorization: `Bearer ${user?.token}` },
      })
      .then((r) => setparams(r.data || []))
      .catch(console.error);

    axios
      .get("http://localhost:5000/api/productions", {
        headers: { Authorization: `Bearer ${user?.token}` },
      })
      .then((r) => setOperations(r.data || []))
      .catch(console.error);
  }, [user?.token, reload]); // 🔁 reload triggers refetch

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer cette opération ?")) {
      try {
        await axios.delete(`http://localhost:5000/api/productions/${id}`, {
          headers: { Authorization: `Bearer ${user?.token}` },
        });
        setOperations((prev) => prev.filter((o) => o._id !== id));
      } catch (err) {
        console.error(err);
      }
    }
  };

  const indexOfLast = currentPage * perPage;
  const indexOfFirst = indexOfLast - perPage;
  const currentOps = operations.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(operations.length / perPage);

  const nextPage = () => currentPage < totalPages && setCurrentPage(currentPage + 1);
  const prevPage = () => currentPage > 1 && setCurrentPage(currentPage - 1);

  return (
    <div className="container">
      <h4 className="mb-3 fw-semibold text-center"> Liste des Opérations</h4>

      <div className="table-responsive shadow-sm border rounded">
        <table className="table table-hover align-middle text-center mb-0">
          <thead className="table-dark">
            <tr>
              <th>Nature</th>
              <th>Client</th>
              <th>Catégorie</th>
              <th>Police</th>
              <th>Mois</th>
              <th>Date Effet</th>
              {
                params.map(
                  (el,i)=><th>{el.name}</th>
                )
              }
              <th>TTC</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentOps.map((op) => {
              const paramTotals =
                op.parameters?.map(
                  (p) =>
                    (p.primes || 0) +
                    (p.taxe || 0) +
                    (p.taxepara || 0) +
                    (p.accessoire || 0) +
                    (p.cnpc || 0)
                ) || [];
              const grandTotal = paramTotals.reduce((a, b) => a + b, 0);

              return (
                <tr key={op._id}>
                  <td className="fw-semibold">{op.natureOperation}</td>
                  <td>{op.client}</td>
                  <td>{op.category}</td>
                  <td className="text-primary">{op.numpolice}</td>
                  <td>
                    {op.moisDem
                      ? new Date(op.moisDem).toLocaleDateString("fr-FR", {
                          month: "short",
                          year: "2-digit",
                        })
                      : "--"}
                  </td>
                  <td>
                    {op.dateEff
                      ? new Date(op.dateEff).toLocaleDateString("fr-FR")
                      : "--"}
                </td> 
                 {
                params.map(
                  (el,i)=><td style={{ minWidth: "260px" }}>
                    primes: 0 DH<br />
                    taxe: 0 DH <br />
                    taxepara: 0 DH <br />
                    accessoire: 0 DH <br />
                    cnpc: 0 DH <br />
                   <span style={{color:"green"}}> total: 0 DH</span>
                  </td>
                )
              }
                   {/* <td className="text-start"> */}
                    {/* {op.parameters && op.parameters.length > 0 ? (
                      <div className="d-flex flex-column gap-2">
                        {op.parameters.map((p, idx) => {
                          const total =
                            (p.primes || 0) +
                            (p.taxe || 0) +
                            (p.taxepara || 0) +
                            (p.accessoire || 0) +
                            (p.cnpc || 0);
                          return (
                            <div key={idx} className="p-2 border rounded bg-light shadow-sm" style={{ fontSize: "13px" }}>
                              <div className="d-flex justify-content-between mb-1">
                                <span className="fw-semibold text-dark">{p.name}</span>
                                <span className="text-success fw-bold">Total: {total.toFixed(2)}</span>
                              </div>
                              <div className="d-flex gap-2 flex-wrap">
                                <span className="badge bg-secondary">Primes: {p.primes || 0}</span>
                                <span className="badge bg-info text-dark">Taxe: {p.taxe || 0}</span>
                                <span className="badge bg-warning text-dark">Para: {p.taxepara || 0}</span>
                                <span className="badge bg-success">Acc: {p.accessoire || 0}</span>
                                <span className="badge bg-danger">CNPC: {p.cnpc || 0}</span>
                              </div>
                            </div>
                          );
                        })} 
                        <div className="border-top pt-2 mt-1 text-end">
                          <strong className="text-success">Total général : {grandTotal.toFixed(2)}</strong>
                        </div>
                      </div>
                    ) : (
                      <span className="text-muted small">Aucun paramètre</span>
                    )} */}
                  {/* </td>  */}
                  <td>
                    TTC: 0 DH
                  </td>
                  <td className="text-center">
                    <button className="btn btn-sm btn-outline-primary" onClick={() => onEdit(op)}>
                      <FaEdit />
                    </button>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(op._id)}>
                      <FaTrash />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="d-flex justify-content-between align-items-center mt-3">
        <button className="btn btn-outline-dark" onClick={prevPage} disabled={currentPage === 1}>
          ← Précédent
        </button>
        <span className="fw-medium">
          Page {currentPage} / {totalPages || 1}
        </span>
        <button className="btn btn-outline-dark" onClick={nextPage} disabled={currentPage === totalPages}>
          Suivant →
        </button>
      </div>
    </div>
  );
}
