import { useState, useEffect } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { Navbar } from "./NavBar";
import CompagneTable from "./CompagneTable";

export default function ListCompagne() {
  const { user, logout } = useAuth();
  const [editId, setEditId] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const [clients, setClients] = useState([]);
  const [categories, setCategories] = useState([]);
  const [allParams, setAllParams] = useState([]);

  const [formData, setFormData] = useState({
    clientName: "",
    category: "",
    indec: "",
    parameters: [{ name: "", percent: 0 }],
  });

  // Load select data
  useEffect(() => {
    const headers = { Authorization: `Bearer ${user?.token}` };

    axios
      .get("http://localhost:5000/api/parametres", { headers })
      .then((res) => setAllParams(res.data || []))
      .catch((err) => console.error(err));

    axios
      .get("http://localhost:5000/api/categories", { headers })
      .then((res) => setCategories(res.data || []))
      .catch((err) => console.error(err));

    // axios
    //   .get("http://localhost:5000/api/clients", { headers })
    //   .then((res) => {
    //     const filtered = (res.data || []).filter((c) => c.type === "societe");
    //     setClients(filtered);
    //   })
    //   .catch((err) => console.error(err));
  }, [user]);

  // Handle form changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleParameterChange = (index, field, value) => {
    const updated = [...formData.parameters];
    updated[index][field] = field === "percent" ? Number(value) : value;
    setFormData((prev) => ({ ...prev, parameters: updated }));
  };

  const addParameter = () => {
    setFormData((prev) => ({
      ...prev,
      parameters: [...prev.parameters, { name: "", percent: 0 }],
    }));
  };

  const removeParameter = (index) => {
    const updated = [...formData.parameters];
    updated.splice(index, 1);
    setFormData((prev) => ({ ...prev, parameters: updated }));
  };

  const handleEdit = (compagne) => {
    setEditId(compagne._id);
    setFormData({
      compagneName: compagne.compagneName || "",
      category: compagne.category || "",
      indec: compagne.indec || "",
      parameters: compagne.parameters || [{ name: "", percent: 0 }],
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();
    const headers = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${user?.token}`,
    };

    try {
      if (editId) {
        await axios.put(
          `http://localhost:5000/api/compagnes/${editId}`,
          formData,
          { headers }
        );
        alert("✅ Compagne modifiée avec succès");
        setEditId(null);
      } else {
        await axios.post("http://localhost:5000/api/compagnes", formData, {
          headers,
        });
        alert("✅ Compagne ajoutée avec succès");
      }

      // Reset form and refresh table
      setFormData({
        compagneName: "",
        category: "",
        indec: "",
        parameters: [{ name: "", percent: 0 }],
      });
      setReloadKey((prev) => prev + 1); // 🔄 refresh CompagneTable
    } catch (err) {
      console.error(err);
      alert("❌ Erreur lors de l’envoi de la compagne");
    }
  };

  return (
    <>
      <Navbar lg={logout} />
      <div className="container mt-4">
        <div className="row">
          {/* Form */}
          <div className="col-lg-5 d-flex align-items-center">
            <div className="w-100 border rounded p-4 bg-light shadow-sm">
              <h3 className="text-center mb-3">
                {editId ? "Modifier la compagne" : "Ajouter une compagne"}
              </h3>

              <form onSubmit={handleSubmit}>
                {/* Client */}
                <div className="mb-2">
                  <label className="form-label">Nom du Compagne</label>
                  <input
                    type="text"
                    name="compagneName"
                    value={formData.compagneName}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                  {/* <select
                    name="clientName"
                    value={formData.clientName}
                    onChange={handleChange}
                    className="form-select"
                    required
                  >
                    <option value="">-- Sélectionner une société --</option>
                    {clients.map((client) => (
                      <option key={client._id} value={client.nom}>
                        {client.nom}
                      </option>
                    ))}
                  </select> */}
                </div>

                {/* Catégorie */}
                <div className="mb-2">
                  <label className="form-label">Catégorie</label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="form-select"
                    required
                  >
                    <option value="">-- Sélectionner une catégorie --</option>
                    {categories.map((category) => (
                      <option key={category._id} value={category.name}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Indice */}
                <div className="mb-2">
                  <label className="form-label">Indice</label>
                  <input
                    type="text"
                    name="indec"
                    value={formData.indec}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>

                {/* Paramètres */}
                <div className="mb-3">
                  <label className="form-label">Paramètres</label>
                  {formData.parameters.map((p, i) => {
                    const availableParams = allParams.filter(
                      (param) =>
                        !formData.parameters
                          .filter((_, idx) => idx !== i)
                          .map((x) => x.name)
                          .includes(param.name)
                    );
                    return (
                      <div
                        key={i}
                        className="d-flex gap-2 mb-2 align-items-center"
                      >
                        <select
                          className="form-select"
                          value={p.name}
                          onChange={(e) =>
                            handleParameterChange(i, "name", e.target.value)
                          }
                          required
                        >
                          <option value="">
                            -- Sélectionner un paramètre --
                          </option>
                          {availableParams.map((param) => (
                            <option key={param._id} value={param.name}>
                              {param.name}
                            </option>
                          ))}
                        </select>

                        <input
                          type="number"
                          placeholder="%"
                          className="form-control"
                          value={p.percent}
                          onChange={(e) =>
                            handleParameterChange(i, "percent", e.target.value)
                          }
                          min={0}
                          max={100}
                          required
                        />

                        {formData.parameters.length > 1 && (
                          <button
                            type="button"
                            className="btn btn-danger btn-sm"
                            onClick={() => removeParameter(i)}
                          >
                            ×
                          </button>
                        )}
                      </div>
                    );
                  })}

                  <div className="text-end">
                    <button
                      type="button"
                      className="btn btn-outline-dark btn-sm"
                      onClick={addParameter}
                    >
                      + Ajouter un paramètre
                    </button>
                  </div>
                </div>

                {/* Submit */}
                {editId ? (
                  <div className="d-flex justify-content-between">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => {
                        setEditId(null);
                        setFormData({
                          clientName: "",
                          category: "",
                          indec: "",
                          parameters: [{ name: "", percent: 0 }],
                        });
                      }}
                    >
                      Annuler
                    </button>
                    <button type="submit" className="btn btn-dark px-4">
                      Mettre à jour
                    </button>
                  </div>
                ) : (
                  <div className="text-center">
                    <button type="submit" className="btn btn-dark px-4">
                      Enregistrer
                    </button>
                  </div>
                )}
              </form>
            </div>
          </div>

          {/* Table */}
          <div className="col-lg-7">
            <CompagneTable onEdit={handleEdit} reloadTrigger={reloadKey} />
          </div>
        </div>
      </div>
    </>
  );
}
