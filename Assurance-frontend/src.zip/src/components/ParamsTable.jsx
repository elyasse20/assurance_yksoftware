import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { FaEdit, FaTrash } from "react-icons/fa";

export default function ParamsTable({ endpoint, handleEdit }) {
  const [parametres, setParametres] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [parametresPerPage] = useState(3);
  const { user } = useAuth();

  // Load data once when user or endpoint changes
  useEffect(() => {
    if (!user?.token) return;
    const fetchParams = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/${endpoint}`, {
          headers: {
            Authorization: `Bearer ${user?.token}`,
          },
        });
        setParametres(res.data || []);
      } catch (err) {
        console.error(err);
      }
    };
    fetchParams();
  }, [endpoint, user?.token,parametres]);

  // Pagination logic
  const indexOfLast = currentPage * parametresPerPage;
  const indexOfFirst = indexOfLast - parametresPerPage;
  const currentItems = parametres.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(parametres.length / parametresPerPage);

  const getIndex = (id) => parametres.findIndex((el) => el._id === id) + 1;

  const nextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };
  const prevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Supprimer ce paramètre ?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/${endpoint}/${id}`, {
        headers: { Authorization: `Bearer ${user?.token}` },
      });
      setParametres((prev) => prev.filter((c) => c._id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="container mt-3">
      <h4 className="mb-3">Liste des {endpoint}</h4>

      <table className="table table-striped table-bordered">
        <thead className="table-dark">
          <tr>
            <th>#</th>
            <th>Nom</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentItems.map((c) => (
            <tr key={c._id}>
              <td>{getIndex(c._id)}</td>
              <td>{c.name}</td>
              <td className="text-center">
                <button
                  className="btn btn-sm btn-outline-primary me-2"
                  onClick={() => handleEdit(c)}
                >
                  <FaEdit />
                </button>
                <button
                  className="btn btn-sm btn-outline-danger"
                  onClick={() => handleDelete(c._id)}
                >
                  <FaTrash />
                </button>
              </td>
            </tr>
          ))}
          {currentItems.length === 0 && (
            <tr>
              <td colSpan="3" className="text-center text-muted">
                Aucun paramètre trouvé
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <div className="d-flex justify-content-between align-items-center mt-3">
        <button
          className="btn btn-secondary"
          onClick={prevPage}
          disabled={currentPage === 1}
        >
          Précédent
        </button>
        <span>
          Page {currentPage} / {totalPages || 1}
        </span>
        <button
          className="btn btn-secondary"
          onClick={nextPage}
          disabled={currentPage === totalPages || totalPages === 0}
        >
          Suivant
        </button>
      </div>
    </div>
  );
}
