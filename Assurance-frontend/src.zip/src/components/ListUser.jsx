import { useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { Navbar } from "./NavBar";
import UserTable from "./UserTable";

export default function ListUser() {
  const { user, logout } = useAuth();
  const [editId, setEditId] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    role: "user",
  });

  const handleEdit = (u) => {
    setEditId(u._id);
    setFormData({
      username: u.username || "",
      email: u.email || "",
      password: "",
      role: u.role || "user",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await axios.put(
          `http://localhost:5000/api/users/${editId}`,
          formData,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${user?.token}`,
            },
          }
        );
        alert("✅ Utilisateur modifié avec succès");
        setEditId(null);
      } else {
        await axios.post("http://localhost:5000/api/users/register", formData, {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${user?.token}`,
          },
        });
        alert("✅ Utilisateur ajouté avec succès");
      }

      setFormData({
        username: "",
        email: "",
        password: "",
        role: "user",
      });
      setReloadTrigger((x) => x + 1); // refresh table
    } catch (err) {
      console.error(err);
      alert("❌ Erreur lors de l’envoi de l’utilisateur");
    }
  };

  const cancelEdit = () => {
    setEditId(null);
    setFormData({
      username: "",
      email: "",
      password: "",
      role: "user",
    });
  };

  return (
    <>
      <Navbar lg={logout} />
      <div className="container mt-4">
        <div className="row">
          <div className="col-lg-5 d-flex align-items-center">
            <div className="w-100 border rounded p-4 bg-light shadow-sm">
              <h3 className="text-center mb-3">
                {editId ? "Modifier l’utilisateur" : "Ajouter un utilisateur"}
              </h3>

              <form onSubmit={handleSubmit}>
                <div className="mb-2">
                  <label className="form-label">Nom d’utilisateur</label>
                  <input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>

                <div className="mb-2">
                  <label className="form-label">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                </div>

                <div className="mb-2">
                  <label className="form-label">
                    {editId
                      ? "Nouveau mot de passe (optionnel)"
                      : "Mot de passe"}
                  </label>
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="form-control"
                    required={!editId}
                  />
                </div>

                <div className="mb-2">
                  <label className="form-label">Rôle</label>
                  <select
                    name="role"
                    value={formData.role}
                    onChange={handleChange}
                    className="form-select"
                  >
                    <option value="user">Utilisateur</option>
                    <option value="admin">Administrateur</option>
                  </select>
                </div>

                {editId ? (
                  <div className="d-flex justify-content-between">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={cancelEdit}
                    >
                      Annuler
                    </button>
                    <button type="submit" className="btn btn-dark px-4">
                      Mettre à jour
                    </button>
                  </div>
                ) : (
                  <div className="text-center">
                    <button type="submit" className="btn btn-dark px-4">
                      Enregistrer
                    </button>
                  </div>
                )}
              </form>
            </div>
          </div>

          <div className="col-lg-7">
            <UserTable onEdit={handleEdit} reloadTrigger={reloadTrigger} />
          </div>
        </div>
      </div>
    </>
  );
}
