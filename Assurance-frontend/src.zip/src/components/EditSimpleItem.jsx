import { useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function EditSimpleItem({ title, endpoint, el, onCancel }) {
  const { user } = useAuth();
  const [item, setItem] = useState(el || { name: "", _id: "" });
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!item.name.trim()) return alert("Le nom est requis");

    try {
      await axios.put(
        `http://localhost:5000/api/${endpoint}/${item._id}`,
        { name: item.name },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${user?.token}`,
          },
        }
      );
      alert(`✅ ${title} modifié(e) avec succès`);
      setTimeout(() => {
        onCancel();
        navigate(`/${endpoint}`);
      }, 500);
    } catch (err) {
      console.error(err);
      alert(`❌ Erreur lors de la modification de ${title.toLowerCase()}`);
    }
  };

  return (
    <div className="col-md-5">
      <div className="border rounded p-4 bg-light shadow-sm">
        <h3 className="text-center mb-3">
          Modifier {title === "Parametre" ? "un" : "une"} {title}
        </h3>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">
              Nom de {title.toLowerCase()}
            </label>
            <input
              type="text"
              className="form-control"
              value={item.name}
              onChange={(e) => setItem({ ...item, name: e.target.value })}
              required
            />
          </div>
          <div className="d-flex justify-content-between">
            <button type="button" className="btn btn-secondary" onClick={onCancel}>
              Annuler
            </button>
            <button type="submit" className="btn btn-dark px-4">
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
