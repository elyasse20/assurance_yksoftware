import { useEffect, useState, useRef } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { FaEdit, FaTrash } from "react-icons/fa";

export default function CompagneTable({ onEdit, reloadTrigger }) {
  const [compagnes, setCompagnes] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage] = useState(5);
  const { user } = useAuth();
  const lastReload = useRef(null); // ✅ to detect true reload only

  const fetchCompagnes = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/compagnes", {
        headers: { Authorization: `Bearer ${user?.token}` },
      });
      setCompagnes(res.data || []);
    } catch (err) {
      console.error(err);
    }
  };

  // ✅ Run only when user token ready or manual reload
  useEffect(() => {
    if (!user?.token) return;
    // prevent duplicate reloads when not intended
    if (lastReload.current === reloadTrigger) return;
    lastReload.current = reloadTrigger;
    fetchCompagnes();
  }, [user?.token, reloadTrigger]);

  const indexOfLast = currentPage * rowsPerPage;
  const indexOfFirst = indexOfLast - rowsPerPage;
  const currentCompagnes = compagnes.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(compagnes.length / rowsPerPage);

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer cette compagne ?")) {
      try {
        await axios.delete(`http://localhost:5000/api/compagnes/${id}`, {
          headers: { Authorization: `Bearer ${user?.token}` },
        });
        await fetchCompagnes(); // refresh after delete
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="container mt-4">
      <h4 className="mb-3">Liste des Compagnes</h4>
      <table className="table table-striped table-bordered">
        <thead className="table-dark">
          <tr>
            <th>Compagne</th>
            <th>Catégorie</th>
            <th>Indice</th>
            <th>Paramètres</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentCompagnes.map((c) => (
            <tr key={c._id}>
              <td>{c.compagneName}</td>
              <td>{c.category}</td>
              <td>{c.indec}</td>
              <td>
                {Array.isArray(c.parameters) && c.parameters.length > 0
                  ? c.parameters.map((p) => `${p.name} (${p.percent}%)`).join(", ")
                  : "--"}
              </td>
              <td className="text-center">
                <button
                  className="btn btn-sm btn-outline-primary me-2"
                  onClick={() => onEdit(c)}
                >
                  <FaEdit />
                </button>
                <button
                  className="btn btn-sm btn-outline-danger"
                  onClick={() => handleDelete(c._id)}
                >
                  <FaTrash />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="d-flex justify-content-between align-items-center mt-3">
        <button
          className="btn btn-secondary"
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((p) => p - 1)}
        >
          Précédent
        </button>

        <span>
          Page {currentPage} / {totalPages || 1}
        </span>

        <button
          className="btn btn-secondary"
          disabled={currentPage === totalPages || totalPages === 0}
          onClick={() => setCurrentPage((p) => p + 1)}
        >
          Suivant
        </button>
      </div>
    </div>
  );
}
