import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export function Navbar() {
  const {logout,user}=useAuth()
  return (
    <nav className="navbar navbar-expand-lg navbar-dark" style={{ background: "#1E293B" }}>
      <div className="container">
        <a className="navbar-brand fw-bold" href="#">
         {user.role=="admin"?"Admin" :"Agent de Saissie"}
        </a>

        <button
      
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto me-3">
            <li className="nav-item">
              <Link className="nav-link" to={"/operations"}>
                Ajouter une Operation
              </Link>
            </li>

            {/* Dropdown */}
            <li className="nav-item dropdown">
              <span
                className="nav-link dropdown-toggle"
                id="configDropdown"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                Config
              </span>
              <ul
                className="dropdown-menu dropdown-menu-dark"
                aria-labelledby="configDropdown"
              >
                
               {user.role === "admin" ? (
  <>
    {["client", "nature", "categorie", "parametre", "compagne", "user"].map((el) => (
      <li key={el}>
        <Link className="dropdown-item" to={`/${el}s`}>
          Liste des {el}s
        </Link>
      </li>
    ))}
  </>
) : (
  <>
    {["client", "nature", "categorie", "parametre", "compagne"].map((el) => (
      <li key={el}>
        <Link className="dropdown-item" to={`/${el}s`}>
          Liste des {el}s
        </Link>
      </li>
    ))}
  </>
)}

              </ul>
            </li>
          </ul>

          {/* Logout button with left margin */}
          <button className={`btn btn-light`} onClick={logout}>
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}
