import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { FaEdit, FaTrash } from "react-icons/fa";

export default function ClientTable({onEdit}) {
  const [clients, setClients] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [clientsPerPage] = useState(5);
  const { user } = useAuth();

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/clients", {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${user?.token}`,
        },
      })
      .then((res) => setClients(res.data))
      .catch((err) => console.error(err));},
       [user?.token,clients]);


  const indexOfLastClient = currentPage * clientsPerPage;
  const indexOfFirstClient = indexOfLastClient - clientsPerPage;
  const currentClients = clients.slice(indexOfFirstClient, indexOfLastClient);
  const totalPages = Math.ceil(clients.length / clientsPerPage);
  const handleEdit = (client) => {
    onEdit(client); // send client data to parent
  };
  
  const nextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };
  const prevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Supprimer ce client ?")) {
      try {
        await axios.delete(`http://localhost:5000/api/clients/${id}`, {
          headers: { Authorization: `Bearer ${user?.token}` },
        });
        setClients(clients.filter((c) => c._id !== id));
      } catch (err) {
        console.error(err);
      }
    }
  };


  return (
    <div className="container mt-4">
      <h4 className="mb-3">Liste des Clients</h4>
      <table className="table table-striped table-bordered">
        <thead className="table-dark">
          <tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Téléphone</th>
            <th>Adresse</th>
            <th>Type</th>
            <th>date debut</th>
            <th>Budget</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {currentClients.map((c) => (
            <tr key={c._id}>
              <td>{c.nom}</td>
              <td>{c.prenom || "--"}</td>
              <td>{c.tel}</td>
              <td>{c.adresse}</td>
              <td>{c.type}</td>
              <td>
              {
                new Date(c.date_debut).toLocaleDateString()
              }
              </td>
            <td>{c.budget}</td>
              <td className="text-center">
                <button
                  className="btn btn-sm btn-outline-primary me-2"
                  onClick={() => handleEdit(c)}
                >
                  <FaEdit />
                </button>
                <button
                  className="btn btn-sm btn-outline-danger"
                  onClick={() => handleDelete(c._id)}
                >
                  <FaTrash />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="d-flex justify-content-between align-items-center mt-3">
        <button
          className="btn btn-secondary"
          onClick={prevPage}
          disabled={currentPage === 1}
        >
          Précédent
        </button>

        <span>
          Page {currentPage} / {totalPages}
        </span>

        <button
          className="btn btn-secondary"
          onClick={nextPage}
          disabled={currentPage === totalPages}
        >
          Suivant
        </button>
      </div>
    </div>
  );
}
