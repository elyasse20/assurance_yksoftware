import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import ParamsTable from "./ParamsTable";
import EditSimpleItem from "./EditSimpleItem";
import { Navbar } from "./NavBar";

export default function AddSimpleItem({ title, endpoint }) {
  const { user,logout } = useAuth();
  const [name, setName] = useState("");
  const [isAdd, setIsAdd] = useState(true);
  const [ele, setEle] = useState(null);

  function handleEdit(element) {
    setIsAdd(false);
    setEle(element);
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) return alert("Le nom est requis");

    try {
      await axios.post(
        `http://localhost:5000/api/${endpoint}`,
        { name },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${user?.token}`,
          },
        }
      );
      alert(`✅ ${title} ajouté(e) avec succès`);
      setName("");
    } catch (err) {
      console.error(err);
      alert(`❌ Erreur lors de l’ajout de ${title.toLowerCase()}`);
    }
  };

  return (<>
        <Navbar lg={logout} />
  
    <div className="container">
      <div className="row align-items-center mt-3" style={{ minHeight: "70vh" }}>
        {isAdd ? (
          <div className="col-md-5">
            <div className="border rounded p-4 bg-light shadow-sm">
              <h3 className="text-center mb-3">
                Ajouter {title === "Parametre" ? "un" : "une"} {title}
              </h3>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">
                    Nom de {title.toLowerCase()}
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder={title.toLowerCase()}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="text-center">
                  <button type="submit" className="btn btn-dark px-4">
                    Ajouter
                  </button>
                </div>
              </form>
            </div>
          </div>
        ) : (
          <EditSimpleItem
            el={ele}
            endpoint={endpoint}
            title={title}
            onCancel={() => setIsAdd(true)}
          />
        )}

        <div className="col-md-7 mt-4 mt-md-0">
          <ParamsTable endpoint={endpoint} handleEdit={handleEdit} title={title} />
        </div>
      </div>
    </div></>
  );
}
